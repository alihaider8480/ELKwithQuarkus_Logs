package org.acme.quickstart;

import java.util.Date;
import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import org.jboss.logging.Logger;

@Path("/gelf-logging")
@ApplicationScoped
public class GelfLoggingResource
{
    private static final Logger LOG = Logger.getLogger(GelfLoggingResource.class);

    @GET
    public String log() {   
        String loggervariable = "Logger Message ! " + new Date();
        LOG.info("Info Some useful log message");
        LOG.trace("Trace message");
        LOG.error("Error Id Not Found");
        return loggervariable;
    }
}